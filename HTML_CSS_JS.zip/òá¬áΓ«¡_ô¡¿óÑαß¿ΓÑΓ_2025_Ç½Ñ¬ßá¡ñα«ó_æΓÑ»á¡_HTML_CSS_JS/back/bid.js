// ФАЙЛ для заполнение полей

let varEge = ["Русский язык", "Математика(Профиль)", "Информатика", "Физика", "Обществознание"];
let count = 0;

let predmets = []; // Выбранные предметы
let ozenka = []; // Баллы по предметам
let snils = ""; // СНИЛС

let formes;
let formesTwo;

function load() {
    formes = document.querySelector(".formes");
    formesTwo = document.querySelector(".formesTwo");
    init();
}

function init() {
    formes.innerHTML = ``;
    let inst = `<p>Регистрация на участие в конкурсе</p>
                <input type="text" id="snils" placeholder="СНИЛС" value="${snils || ''}">
                <select id="inst" onchange="ouo(this)">
                    <option disabled selected>Выберите предмет</option>`;
    
    for(let i = 0; i < varEge.length; i++) {
        inst += `<option value="${i}">${varEge[i]}</option>`;
    }
    inst += `</select>`;
    formes.innerHTML = inst;
}

function ouo(selectElement) {
    // Сохраняем текущие значения input перед обновлением
    saveInputValues();
    
    // Добавляем выбранный предмет
    predmets.push(varEge[selectElement.value]);
    
    // Обновляем список доступных предметов
    varEge = varEge.filter(item => item !== varEge[selectElement.value]);
    init();

    // Обновляем форму
    updateForm();
    
    // Восстанавливаем сохраненные значения
    restoreInputValues();
}

function updateForm() { // Обновление формы
    formesTwo.innerHTML = '';

    if (predmets.length == 5){
        alert("Вы не можете выбрать больше 5 предметов");
    }
    else {
        if (predmets.length > 0) {
            formesTwo.innerHTML += `<p id="ball">Баллы ЕГЭ</p>`;
            
            for (let i = 0; i < predmets.length; i++) {
                formesTwo.innerHTML += `
                    <div class="predmet">
                        <p id="textPred">${predmets[i]}</p>
                        <input type="text" class="pred" id="pred${i+1}" value="${ozenka[i] || ''}">
                    </div>
                `;
            }
            
            if (predmets.length >= 3) {
                formesTwo.innerHTML += `<button id="finish" onclick="finish()">Подать заявку</button>`;
            }
        }
        
        count = predmets.length;
    }
}

function saveInputValues() { // Сохранение инпутов
    // Сохраняем СНИЛС
    const snilsInput = document.getElementById("snils");
    if (snilsInput) snils = snilsInput.value;
    
    // Сохраняем баллы
    ozenka = [];
    for (let i = 1; i <= 5; i++) {
        const input = document.getElementById(`pred${i}`);
        if (input) ozenka.push(input.value);
    }
}

function restoreInputValues() { // Востановление инпутов
    // Восстанавливаем СНИЛС
    const snilsInput = document.getElementById("snils");
    if (snilsInput) snilsInput.value = snils;
    
    // Восстанавливаем баллы
    for (let i = 0; i < ozenka.length; i++) {
        const input = document.getElementById(`pred${i+1}`);
        if (input) input.value = ozenka[i];
    }
}

function finish() { // Отправка
    saveInputValues(); // Сохраняем последние введенные данные
    
    console.log("СНИЛС:", snils);
    console.log("Предметы:", predmets);
    console.log("Баллы:", ozenka);
    
    // Здесь можно добавить отправку данных на сервер
    alert("Заявка отправлена!");
}

function clickLogout() {
    alert("Возвращение");
    window.location.replace("main.html");
}

// Инициализация при загрузке
window.onload = load;

// ТОлько 1 страниа index
// Все проверки в JS
// Добавить код перенос с сервера в JS -> html
// Пользователь зашёл успешно - localstoradge
// Чтение удаление изменение в JS
