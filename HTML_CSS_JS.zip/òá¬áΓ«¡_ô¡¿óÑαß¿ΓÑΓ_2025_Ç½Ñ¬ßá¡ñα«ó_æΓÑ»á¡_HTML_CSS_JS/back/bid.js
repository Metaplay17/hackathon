let mySpez = 0;
let INST = 0;
const intitut = ["ИСАУ", "ФСГН", "ИФИ", "ФИН"];
const spezISAY = [
    "Программная инженерия",
    "Информационно вычислительная техника"
];
const varEge = [
    ["Русский язык", "Математика(Профиль)", "Информатика", "Физика"],
    ["Русский язык", "Математика(Профиль)", "Информатика", "Обществознание"]
];

document.addEventListener("DOMContentLoaded", () => {
    formes = document.querySelector(".formes");
    
    // Создаем первый select
    let inst = `<p>Регистрация на участие в конкурсе</p>
                <select id="inst">
                    <option value="">Выберите институт</option>`;
    for(let i = 0; i < intitut.length; i++) {
        inst += `<option value="${i}">${intitut[i]}</option>`;
    }
    inst += `</select>`;
    formes.innerHTML = inst; // Используем = вместо +=

    // Обработчик выбора института
    document.getElementById('inst').addEventListener('change', function() {
        INST = this.value;
        updateSpecializations();
    });
});

function updateSpecializations() {
    let napr = `<select id="inp"><option value="">Выберите направление</option>`;
    
    if (INST == 0) {
        for(let i = 0; i < spezISAY.length; i++) {
            napr += `<option value="${i}">${spezISAY[i]}</option>`;
        }
    }
    
    napr += `</select>`;
    formes.innerHTML += napr;
    
    // Добавляем обработчик после создания элемента
    document.getElementById('inp').addEventListener('change', function() {
        mySpez = this.value;
        showStudentForm();
    });
}

function showStudentForm() {
    const FN = `
        <input type="text" id="sur_name" placeholder="Фамилия">
        <input type="text" id="name" placeholder="Имя">
        <input type="text" id="father_name" placeholder="Отчество">
        <p id="ball">Баллы ЕГЭ</p>
    `;
    
    let text = ``;
    for(let i = 0; i < varEge[mySpez].length; i++) {
        text += `<input type="text" id="pred${i}" placeholder="${varEge[mySpez][i]}">`;
    }
    
    formes.innerHTML += FN + text;
}

function clickLogout() {
    alert("Возвращение");
    window.location.replace("main.html");
}
