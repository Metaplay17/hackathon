
let numerNapr = 0;
let formeres;
let spiskises;
let napr;

function loading() {
    napr = document.getElementById("napravlenie");
    spiskises = document.getElementById("spiskis");
    formeres = document.getElementById("formeres");
    init();
}
function init() {
    napr.innerHTML = `<select name="nap" id="napravlen" onchange="changeNapr(this)">
        <option disabled selected>Выберите направление</option>
        <option value="0">Программная инженерия</option>
        <option value="1">ИВТ</option>
        <option value="2">ПИ</option>
        <option value="3">Экономика</option>
        <option value="4">ИСТ</option>
    </select>`;
}
function changeNapr(napravl) {
    numerNapr = napravl.value;
    formeres.innerHTML = `<form>
        <div class="viborSpiska">
            <p>Общий</p>
            <input type="radio" name="typeSpisok" value="general" onchange="handleRadioChange(this)">
        </div>
        <div class="viborSpiska">
            <p>Оригинальные атестаты</p>
            <input type="radio" name="typeSpisok" value="originals" onchange="handleRadioChange(this)">
        </div>
        <div class="viborSpiska">
            <p>Итоговый список с учётом приоритетов</p>
            <input type="radio" name="typeSpisok" value="priorities" onchange="handleRadioChange(this)">
        </div>
    </form>`;
}

function handleRadioChange(radio) { // При выборе другого radio
    if (radio.checked) { // Тестовый
            const jsonString = JSON.stringify([
                {
                    "n":1,
                    "snils":9847532975023,
                    "sumBalls":254,
                    "priority":1
                },
                {
                    "n":2,
                    "snils":98709873423,
                    "sumBalls":234,
                    "priority":2
                }
            ]);
            /* НУЖНО ОТПРАВИТЬ ЗАПРОС НА СЕРВЕР */
            console.log(jsonString);
            /*json = return radio.value;*/
            addSpisokOnDisplay(JSON.parse(jsonString));
    }
}

function addSpisokOnDisplay(jsonString) {
    let text = ``; // Поменять n, priority, snils, sumBalls
    for(let i = 0; i < jsonString.length; i++){
        console.log(jsonString[i]);
        console.log(jsonString[i].n);
        if (i == 0) {
            text += `<div id="underSpisok">
        <p id="n">Номер</p>
        <p id="snils">Снилс</p>
        <p id="sumBalls">Сумма баллов</p>
        <p id="priority">Приоритет</p>
    </div>`;
        }
        text += `<div id="underSpisok">
        <p id="n">${jsonString[i].n}</p>
        <p id="snils">${jsonString[i].snils}</p>
        <p id="sumBalls">${jsonString[i].sumBalls}</p>
        <p id="priority">${jsonString[i].priority}</p>
    </div>`;
    spiskises.innerHTML = text;
    }
}