let formeres;
let spiskises;
function loading() {
    spiskises = document.getElementById("spiskis");
    formeres = document.getElementById("formeres");
    init()
}
function init() {
    formeres.innerHTML = `<form>
        <div class="viborSpiska">
            <p>Общий</p>
            <input type="radio" name="typeSpisok" value="general" onchange="handleRadioChange(this)">
        </div>
        <div class="viborSpiska">
            <p>Оригинальные атестаты</p>
            <input type="radio" name="typeSpisok" value="originals" onchange="handleRadioChange(this)">
        </div>
        <div class="viborSpiska">
            <p>Итоговый список с учётом приоритетов</p>
            <input type="radio" name="typeSpisok" value="priorities" onchange="handleRadioChange(this)">
        </div>
    </form>`;
}

function handleRadioChange(radio) { // При выборе другого radio
    if (radio.checked) { // Тестовый
            const jsonString = JSON.stringify([
                {
                    "n":1,
                    "priority":1,
                    "snils":9847532975023,
                    "sumBalls":254
                },
                {
                    "n":2,
                    "priority":2,
                    "snils":98709873423,
                    "sumBalls":234
                }
            ]);
            console.log(jsonString);
            /*json = return radio.value;*/
            addSpisokOnDisplay(JSON.parse(jsonString));
    }
}

function addSpisokOnDisplay(jsonString) {
    let text = ``; // Поменять n, priority, snils, sumBalls
    for(let i = 0; i < jsonString.length; i++){
        console.log(jsonString[i]);
        console.log(jsonString[i].n);
        if (i == 0) {
            text += `<div id="underSpisok">
        <p id="n">Номер</p>
        <p id="snils">Снилс</p>
        <p id="sumBalls">Сумма баллов</p>
        <p id="priority">Приоритет</p>
    </div>`;
        }
        text += `<div id="underSpisok">
        <p id="n">${jsonString[i].n}</p>
        <p id="snils">${jsonString[i].snils}</p>
        <p id="sumBalls">${jsonString[i].sumBalls}</p>
        <p id="priority">${jsonString[i].priority}</p>
    </div>`;
    spiskises.innerHTML = text;
    }
}