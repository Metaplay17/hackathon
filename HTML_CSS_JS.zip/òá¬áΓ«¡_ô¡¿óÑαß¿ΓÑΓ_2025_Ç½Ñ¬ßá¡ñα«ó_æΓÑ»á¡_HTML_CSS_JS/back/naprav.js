let napzavlen = ["Программная инженерия", "ИВТ", "ПИ", "Экономика", "ИСТ"];
let count = 0;

let predmeteses = [
    ["Русский язык", "Математика(Профиль)", "Информатика", "Физика"]
]

let napravlenies = []; // Выбранные направления
let prioritets = []; // Приоритеты

let formes;
let formesTwo;

let saved = JSON.parse(localStorage.getItem('userVib')); // Выбранные предметы и баллы
let predmetVivor = saved.pr;
let ozenksVibor = saved.oz;

function load() {

    formes = document.querySelector(".formes");
    formesTwo = document.querySelector(".formesTwo");
    init();
}

function init() {
    formes.innerHTML = ``;
    let inst = `<p>Регистрация на участие в конкурсе</p>
                <select id="inst" onchange="ouo(this)">
                    <option disabled selected>Выберите направление</option>`;
    
    for(let i = 0; i < napzavlen.length; i++) {
        inst += `<option value="${i}">${napzavlen[i]}</option>`;
    }
    inst += `</select>`;
    formes.innerHTML = inst;
}

function ouo(selectElement) {
    // Сохраняем текущие значения input перед обновлением
    saveInputValues();
    
    // Добавляем выбранный предмет
    napravlenies.push(napzavlen[selectElement.value]);
    
    // Обновляем список доступных предметов
    napzavlen = napzavlen.filter(item => item !== napzavlen[selectElement.value]);
    init();

    // Обновляем форму
    updateForm();
    
    // Восстанавливаем сохраненные значения
    restoreInputValues();
}

function updateForm() { // Обновление формы
    formesTwo.innerHTML = '';

    if (napravlenies.length == 5){
        alert("Вы не можете выбрать больше 5 предметов");
    }
    else {
        if (napravlenies.length > 0) {
            formesTwo.innerHTML += `<p id="ball">Приоритеты</p>`;
            
            for (let i = 0; i < napravlenies.length; i++) {
                formesTwo.innerHTML += `
                    <div class="predmet">
                        <p id="textPred">${napravlenies[i]}</p>
                        <input type="text" class="pred" id="pred${i+1}" value="${prioritets[i] || ''}">
                    </div>
                `;
            }
            
            if (napravlenies.length >= 1) {
                formesTwo.innerHTML += `<button id="finish" onclick="finish()">Подать заявку</button>`;
            }
        }
        
        count = napravlenies.length;
    }
}

function saveInputValues() { // Сохранение инпутов
    // Сохраняем баллы
    prioritets = [];
    for (let i = 1; i <= 5; i++) {
        const input = document.getElementById(`pred${i}`);
        if (input) prioritets.push(input.value);
    }
}

function restoreInputValues() { // Востановление инпутов
    // Восстанавливаем баллы
    for (let i = 0; i < prioritets.length; i++) {
        const input = document.getElementById(`pred${i+1}`);
        if (input) input.value = prioritets[i];
    }
}

function finish() { // Отправка
    saveInputValues(); // Сохраняем последние введенные данные
    
    console.log("Предметы:", napravlenies);
    console.log("Баллы:", prioritets);

    
    alert("Заявка успешно отправлена!");
    window.location.replace("...");
    // Здесь можно добавить отправку данных на сервер
}

// Инициализация при загрузке
window.onload = load;