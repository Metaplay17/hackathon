function clickZayavka() { // Нажатие на кнопку "Заявка"
    alert("Заявка на поступление");
    window.location.replace("bid.html");
}

function clickWatch() { // Нажатие на кнопку "Просмотр поступающих"
    alert("Просмотр поступающих");
}